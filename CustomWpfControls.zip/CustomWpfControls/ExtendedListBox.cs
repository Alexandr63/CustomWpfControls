﻿using CustomWpfControls.Tools;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;

namespace CustomWpfControls
{
    public static class ListViewBehaviors
    {
        public static readonly DependencyProperty ContentTransformProperty = DependencyProperty.RegisterAttached("ContentTransform", typeof(Transform), typeof(ListViewBehaviors),
            new PropertyMetadata((Transform)null, OnContentTransformChanged));

        public static Transform GetContentTransform(ListView obj)
        {
            return (Transform)obj.GetValue(ContentTransformProperty);
        }

        public static void SetContentTransform(ListView obj, Transform value)
        {
            obj.SetValue(ContentTransformProperty, value);
        }

        private static void OnContentTransformChanged(DependencyObject obj, DependencyPropertyChangedEventArgs e)
        {
            ListView view = obj as ListView;
            if (view != null)
            {
                if (view.ItemContainerGenerator.Status != GeneratorStatus.ContainersGenerated)
                {
                    EventHandler handler = null;
                    handler = (s, a) => ListView_ItemContainerGenerator_StatusChanged(view, handler);
                    view.ItemContainerGenerator.StatusChanged += handler;
                }
                else
                {
                    UpdateTransform(view);
                }
            }
        }

        private static void ListView_ItemContainerGenerator_StatusChanged(ListView view, EventHandler handler)
        {
            if (view.ItemContainerGenerator.Status == GeneratorStatus.ContainersGenerated)
            {
                view.ItemContainerGenerator.StatusChanged -= handler;
                UpdateTransform(view);
            }
        }

        private static void UpdateTransform(ListView view)
        {
            if (view.IsArrangeValid)
            {
                DoUpdateTransform(view);
            }
            else
            {
                EventHandler handler = null;
                handler = (s, e) => LayoutUpdated(view, handler);
                view.LayoutUpdated += handler;
            }
        }

        private static void LayoutUpdated(ListView view, EventHandler handler)
        {
            view.LayoutUpdated -= handler;
            DoUpdateTransform(view);
        }

        private static void DoUpdateTransform(ListView view)
        {
            ScrollViewer scroller = VisualTreeUtility.FindDescendant<ScrollViewer>(view);
            if (scroller != null)
            {
                Transform transform = GetContentTransform(view);

                FrameworkElement header = VisualTreeUtility.FindDescendant<ScrollViewer>(scroller);
                if (header != null)
                {
                    header.LayoutTransform = transform;
                }

                FrameworkElement content = scroller.Template.FindName("PART_ScrollContentPresenter", scroller) as FrameworkElement;
                if (content != null)
                {
                    content.LayoutTransform = transform;
                }
            }
        }
    }

    public static class VisualTreeUtility
    {
        public static T FindDescendant<T>(DependencyObject ancestor) where T : DependencyObject
        {
            return FindDescendant<T>(ancestor, item => true);
        }

        public static T FindDescendant<T>(DependencyObject ancestor, Predicate<T> predicate) where T : DependencyObject
        {
            return FindDescendant(typeof(T), ancestor, item => predicate((T)item)) as T;
        }

        public static DependencyObject FindDescendant(Type itemType, DependencyObject ancestor, Predicate<DependencyObject> predicate)
        {
            if (itemType == null) throw new ArgumentNullException("itemType");
            if (ancestor == null) throw new ArgumentNullException("ancestor");
            if (predicate == null) throw new ArgumentNullException("predicate");
            if (!typeof(DependencyObject).IsAssignableFrom(itemType)) throw new ArgumentException("itemType", "The passed in type must be or extend DependencyObject");

            Queue<DependencyObject> queue = new Queue<DependencyObject>();
            queue.Enqueue(ancestor);

            while (queue.Count > 0)
            {
                DependencyObject currentChild = queue.Dequeue();
                if (currentChild != ancestor && itemType.IsAssignableFrom(currentChild.GetType()))
                {
                    if (predicate.Invoke(currentChild))
                    {
                        return currentChild;
                    }
                }

                int count = VisualTreeHelper.GetChildrenCount(currentChild);
                for (int i = 0; i < count; ++i)
                {
                    queue.Enqueue(VisualTreeHelper.GetChild(currentChild, i));
                }
            }

            return null;
        }
    }

    public class ExtendedListBox : ListBox
    {
        public ExtendedListBox()
        {
            AddHandler(MouseWheelEvent, new MouseWheelEventHandler(OnMouseWheel), true);

            Loaded += ExtendedListBox_Loaded;
            SourceUpdated += ExtendedListBox_SourceUpdated;

            ((INotifyCollectionChanged) Items).CollectionChanged += CollectionChangedEventHandler;
        }
        
        /// <summary>
        /// Множитель размера элементов, используемый в данный момент для отображения 
        /// </summary>
        public double Scale
        {
            get => (double)GetValue(ScaleProperty);
            set => SetValue(ScaleProperty, value);
        }

        public static readonly DependencyProperty ScaleProperty = DependencyProperty.Register(nameof(Scale), 
            typeof(double),
            typeof(ExtendedListBox), 
            new UIPropertyMetadata(1d));


        /// <summary>
        /// Минимальный размер отображаемого элемента.
        /// </summary>
        public double MinItemSize
        {
            get => (double)GetValue(MinItemSizeProperty);
            set => SetValue(MinItemSizeProperty, value);
        }

        public static readonly DependencyProperty MinItemSizeProperty = DependencyProperty.Register(nameof(MinItemSize), 
            typeof(double),
            typeof(ExtendedListBox),
            new UIPropertyMetadata(100d));

        /// <summary>
        /// Максимальный размер отображаемого элемента.
        /// </summary>
        public double MaxItemSize
        {
            get => (double)GetValue(MaxItemSizeProperty);
            set => SetValue(MaxItemSizeProperty, value);
        }

        public static readonly DependencyProperty MaxItemSizeProperty = DependencyProperty.Register(nameof(MaxItemSize),
            typeof(double), 
            typeof(ExtendedListBox),
            new UIPropertyMetadata(1500d));

        public bool ResizeEnable
        {
            get => (bool)GetValue(ResizeEnableProperty);
            set => SetValue(ResizeEnableProperty, value);
        }

        public static readonly DependencyProperty ResizeEnableProperty = DependencyProperty.Register(nameof(ResizeEnable),
            typeof(bool),
            typeof(ExtendedListBox),
            new UIPropertyMetadata(true));


        private void ResizeAll(double newScaleFactor)
        {
            System.Diagnostics.Debug.WriteLine($">>>ResizeAll ---------------------------------------------------");
            System.Diagnostics.Debug.WriteLine($">>> Items.Count: {Items.Count}");
            List<ListBoxItem> listBoxItems = Items.Cast<object>()
                .Select(item => (ListBoxItem)ItemContainerGenerator.ContainerFromItem(item))
                .ToList();

            bool needMeasure = false;
            foreach (ListBoxItem item in listBoxItems)
            {
                ResizeItem(item, newScaleFactor, ref needMeasure);
            }

            Scale = newScaleFactor;
            
            if (needMeasure)
            {
                InvalidateMeasure();
            }
        }

        private void ResizeNewItems(List<ListBoxItem> items, double newScaleFactor)
        {
            System.Diagnostics.Debug.WriteLine($">>>ResizeNewItems ---------------------------------------------------");
            System.Diagnostics.Debug.WriteLine($">>> items.Count: {items.Count}");

            bool needMeasure = false;
            foreach (ListBoxItem item in items)
            {
                if (item == null || item.DesiredSize == SizeHelper.ZeroSize)
                {
                    System.Diagnostics.Debug.WriteLine($">>> item null or item.DesiredSize == SizeHelper.ZeroSize");
                    continue;
                }

                if (double.IsNaN(item.Width) || double.IsNaN(item.Height))
                {
                    System.Diagnostics.Debug.Write($">>> set value ");
                    item.Width = item.DesiredSize.Width * Scale;
                    item.Height = item.DesiredSize.Height * Scale;
                }
                else
                {
                    System.Diagnostics.Debug.Write($">>> scale ");
                    item.Width = (item.Width / Scale) * newScaleFactor;
                    item.Height = (item.Height / Scale) * newScaleFactor;
                }

                needMeasure = true;

                System.Diagnostics.Debug.WriteLine($">>> {item.Width} x {item.Height} | {item.DesiredSize} | {item.RenderSize}");
            }

            if (needMeasure)
            {
                InvalidateMeasure();
            }
        }

        private void ResizeItem(ListBoxItem item, double newScaleFactor, ref bool needMeasure)
        {
            if (item == null || item.DesiredSize == SizeHelper.ZeroSize)
            {
                System.Diagnostics.Debug.WriteLine($">>> item null or item.DesiredSize == SizeHelper.ZeroSize");
                return;
            }

            FrameworkElement content = ControlsHelper.GetVisualChild<FrameworkElement>(item);
            if (content != null)
            {
                
                //if (item.DesiredSize == SizeHelper.ZeroSize)
                //{
                //    item.InvalidateMeasure();
                //}

                if (double.IsNaN(content.Width) || double.IsNaN(content.Height))
                {
                    System.Diagnostics.Debug.Write($">>> set value ");
                    content.Width = content.DesiredSize.Width * Scale;
                    content.Height = content.DesiredSize.Height * Scale;
                }
                else
                {
                    System.Diagnostics.Debug.Write($">>> scale ");
                    content.Width = (content.Width / Scale) * newScaleFactor;
                    content.Height = (content.Height / Scale) * newScaleFactor;
                }

                needMeasure = true;

                System.Diagnostics.Debug.WriteLine($">>> {content.Width} x {content.Height} | {content.DesiredSize} | {content.RenderSize}");
            }
        }

        private void ExtendedListBox_Loaded(object sender, RoutedEventArgs e)
        {
            ResizeAll(0.25d);
        }
        
        private void ExtendedListBox_SourceUpdated(object sender, DataTransferEventArgs e)
        {
            throw new NotImplementedException();
            // Resize(_scaleFactor);
        }

        private void CollectionChangedEventHandler(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems == null)
            {
                return;
            }

            System.Diagnostics.Debug.WriteLine($">>>CollectionChangedEventHandler ---------------------------------------------------");

            List<ListBoxItem> newListBoxItems = e.NewItems.Cast<object>()
                .Select(item => (ListBoxItem)ItemContainerGenerator.ContainerFromItem(item))
                .ToList();
            foreach (ListBoxItem item in newListBoxItems)
            {
                item.InvalidateMeasure();
                System.Diagnostics.Debug.WriteLine($">>> {item.Width} x {item.Height} | {item.DesiredSize} | {item.RenderSize}");
            }

            return;

            if (e.NewItems == null)
            {
                return;
            }

            //List<ListBoxItem> newListBoxItems = e.NewItems.Cast<object>()
            //    .Select(item => (ListBoxItem)ItemContainerGenerator.ContainerFromItem(item))
            //    .ToList();

            InvalidateMeasure();

            // ResizeNewItems(newListBoxItems);
        }

        //private List<FrameworkElement> GetChildElements()
        //{
        //    List<FrameworkElement> elements = new List<FrameworkElement>()
        //}

        private void OnMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (Keyboard.Modifiers != ModifierKeys.Control)
            {
                return;
            }

            double newScaleFactor = Scale;
            
            if (e.Delta > 0)
            {
                newScaleFactor *= 1.1;
            }
            else
            {
                newScaleFactor *= 0.9;
            }
            
            ResizeAll(newScaleFactor);
            
            e.Handled = true;
        }
    }
}
